ساختار بسته الگو:

  company.json              اطلاعات پایه‌ای شرکت
  logo.png|jpg|svg          لوگوی شرکت
  gallery/*.jpg|png|webp    تصاویر گالری
  products/<نام محصول>/
    info.json               { "name", "description", "url" }
    images/*                عکس‌های محصول
    videos/*                ویدئوهای محصول
  catalog.pdf|docx          کاتالوگ محصولات
  form_fa.docx              فرم/مستندات فارسی
  form_en.docx              فرم/مستندات انگلیسی
  documents/*               سایر اسناد آزاد

فایل‌های خالی یا غایب نادیده گرفته می‌شوند.
